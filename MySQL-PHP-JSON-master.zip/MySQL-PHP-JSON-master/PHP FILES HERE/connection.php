<?php

define('hostname', 'localhost');
define('user', 'root');
define('password', '');
define('databaseName', 'tutorial');


$connect = mysqli_connect(hostname, user, password, databaseName);

?>